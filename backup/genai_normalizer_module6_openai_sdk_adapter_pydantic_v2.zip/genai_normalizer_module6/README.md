# GenAI Normalizer — Module 6: OpenAI SDK Adapter (Pydantic v2)

Depends on Modules 1 and 2.

Requires:

    pydantic>=2.8,<3

This module provides strict Pydantic v2 adapter models for OpenAI SDK and raw
HTTP payloads. It does not require importing the OpenAI package.

Implemented:

- Pydantic v2 request envelopes
- Pydantic v2 Chat Completions response models
- Pydantic v2 Responses API response models
- Pydantic v2 usage models
- SDK/raw-object adapter
- TypeAdapter-based validation
- Conversion to the Module 1 normalized models
- Tests
